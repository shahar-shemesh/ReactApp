import React from "react";

export class HandleSubmitExample extends React.Component{

    handleSubmit(e){
        e.preventDefault(); // אם מבטלים את השורה הזו אז מתבצע מעבר לדף אחר
        alert('YAAA, new window do not open');
    }

    render() {
      return (
            <form onSubmit={this.handleSubmit}>
                <button type="submit">HandleSubmitExample</button>
            </form>
      )
    }

}
// ===================================================== //


