import React from "react";

export class NameFormExample extends React.Component{
    constructor(props){
        super(props);
        this.state = {value: ''};
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    
    //bind = זה בעצם קורא לפונקציה שעליה מופעל הביינד, שהאובייקט הראשון
                // שנשלח הוא יהיה ה-this

    }
        


    handleChange(event){
        this.setState(
            {value: event.target.value}
        );
        console.log(this.value);
    }
    handleSubmit(event){
        alert(this.state.value);
        this.referenceToInput.value = ''; // כדי שהאינפוט יתנקה
        event.preventDefault(); // כדי שלא יתרענן הדף
    }

    render() {
      return (
        <form onSubmit={this.handleSubmit}>
          
          <label>Name: 
            <input
                type='text'
                value={this.state.value}
                onChange={this.handleChange}
                ref = { (currentEvent) => {this.referenceToInput = currentEvent;} }
                >
            </input>
            {/* <textarea value={this.state.value} onChange={this.handleChange}/> */}
            <input type="submit" value='Send'/>
            {/* <button type="submit" value='Send'>asad</button> */}
            </label>

        </form>
      )
    }


}
// ===================================================== //


