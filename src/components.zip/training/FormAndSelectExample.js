import React from "react";

export class FormAndSelectExample extends React.Component{
    constructor(props){
        super(props);
        this.state = {selectedValue: 'food',
            options: ['food','drink']
            
    };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event){
        this.setState(
            {selectedValue: event.target.value}
        );
    }
    handleSubmit(event){
        alert(this.state.selectedValue);
        event.preventDefault(); // כדי שלא יתרענן הדף
    }

    render() {
      return (
        <form onSubmit={this.handleSubmit}>
          <label>Pick your favorite category: 
            <select multiple={true} value={this.state.value} onChange={this.handleChange}>
                <option value='food'>Food</option>
                <option value='drink'>Drink</option>
                {/* <option>Drink</option> \\ אם רוצים שהערך שמוצג יהיה הערך האמיתי*/} 
                <option value='hobbies'>Hobbies</option>
                <option value='other'>Other</option>
            </select>

          </label>
          <input type="submit" value='SelectExample'/>
        </form>
      )
    }


}
// ===================================================== //


