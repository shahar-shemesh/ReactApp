import React, {Component, useState} from 'react'
import { GetFromLocalStorage } from '../localStorageLibrary/GetFromLocalStorage';
import { v4 as uuid } from 'uuid';
import ItemForm from './ItemForm';

export const AddItem = (props) => { 

    const onBuildNewItem = (pieceOfItemData) => {
		//const buildNewItem = {...pieceOfItemData, };
		props.onNewItem(pieceOfItemData);
    };

    return(
        <ItemForm onBuildNewItem = {onBuildNewItem}/>
    );
};

