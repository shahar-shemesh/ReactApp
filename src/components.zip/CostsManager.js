import React from 'react';

export class CostsManager extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      costItems: [],
      newCostItem: {
        sum: '',
        category: '',
        description: '',
      },
      selectedMonth: '',
      selectedYear: '',
    };
  }

  handleInputChange = (event) => {
    const { name, value } = event.target;
    this.setState((prevState) => ({
      newCostItem: { ...prevState.newCostItem, [name]: value },
    }));
  };

  handleMonthChange = (event) => {
    this.setState({ selectedMonth: event.target.value });
  };

  handleYearChange = (event) => {
    this.setState({ selectedYear: event.target.value });
  };

  handleAddCostItem = (event) => {
    event.preventDefault();
    this.setState((prevState) => ({
      costItems: [...prevState.costItems, prevState.newCostItem],
      newCostItem: {
        sum: '',
        category: '',
        description: '',
      },
    }));
  };

  handleGenerateReport = (event) => {
    event.preventDefault();
    const { selectedMonth, selectedYear } = this.state;
    // Generate report logic here
  };

  render() {
    const { newCostItem, selectedMonth, selectedYear } = this.state;
    return (
      <div>
        <form onSubmit={this.handleAddCostItem}>
          <label>
            Sum:
            <input type="number" name="sum" value={newCostItem.sum} onChange={this.handleInputChange} />
          </label>
          <br />
          <label>
            Category:
            <select name="category" value={newCostItem.category} onChange={this.handleInputChange}>
              <option value="food">Food</option>
              <option value="transportation">Transportation</option>
              <option value="entertainment">Entertainment</option>
              <option value="other">Other</option>
            </select>
          </label>
          <br />
          <label>
            Description:
            <input type="text" name="description" value={newCostItem.description} onChange={this.handleInputChange} />
          </label>
          <br />
          <button type="submit">Add Cost Item</button>
        </form>
        <br />
        <form onSubmit={this.handleGenerateReport}>
          <label>
            Month:
            <input type="text" name="month" value={selectedMonth} onChange={this.handleMonthChange} />
          </label>
          <br />
          <label>
            Year:
            <input type="text" name="year" value={selectedYear} onChange={this.handleYearChange} />
          </label>
          <br />
          <button type="submit">Generate Report</button>
        </form>
      </div>
    );
  }
}
