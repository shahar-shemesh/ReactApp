import './App.css';
import {Header} from './components/Header';
import {AddItem} from './components/AddItem';
import {Clock} from './components/Clock';
import {IsToggleOnExample} from './training/IsToggleOnExample';
import {NameFormExample} from './training/NameFormExample';
import {HandleSubmitExample} from './training/HandleSubmitExample';
import {FormAndSelectExample} from './training/FormAndSelectExample';
import {Categories} from './components/Categories'
import { Component, useEffect, useState } from 'react';
import Exception from './components/Exception';
import { useLocalStorage } from "./useLocalStorage";
import { ItemList } from './components/ItemsList';


export default function App() {


  const [items, setItems] = useLocalStorage('myData', []);

  const handleNewItem = (item) => {
    // console.log(Object.keys(item).toString());
    
    setItems(prevItem => { return [item, ...prevItem];
      });
    };

    return (
      <div className="App">
        <Exception>
            <Header/>
            
            <AddItem onNewItem = {handleNewItem}/>
            <ItemList items={items}/>

            <Clock/>
        </Exception>
      </div>
    );
};