import React, {Component} from 'react'

export class GetFromLocalStorage extends Component{ 

    constructor(props){
        super(props);
        this.state = {
            selectedDate: this.props.month + '/' + this.props.year
        };
    }

    getData =(() =>{
        const getStored = localStorage.getItem(this.state.selectedDate);
        if(getStored == null){
            
        }
        else{
            const stored = localStorage.getItem(this.state.selectedDate);
            const currentCart  = JSON.parse(stored);
            currentCart.map((each) => console.log(each)); 
        }
    });

    render() {
      return (
        <>
            <button onClick={this.getData}>Get</button>
        </>
      )
    }



}
